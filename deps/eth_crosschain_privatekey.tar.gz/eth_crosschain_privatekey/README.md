# eth_crosschain_privatekey
eth privatekey plugin
